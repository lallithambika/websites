import Image from "next/image"
import Link from "next/link"
import {
  Users,
  Globe,
  Award,
  TrendingUp,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Code,
  Smartphone,
  Cloud,
  Database,
  Shield,
  Zap,
  ArrowRight,
  Star,
  CheckCircle,
  Play,
  Calendar,
  MapPin,
  Mail,
  Phone,
} from "lucide-react"

export default function HomePage() {
  const universities = [
    { name: "Harvard University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Stanford University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "MIT", logo: "/placeholder.svg?height=80&width=120" },
    { name: "University of California Berkeley", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Oxford University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Cambridge University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Yale University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Princeton University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Columbia University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "University of Chicago", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Carnegie Mellon University", logo: "/placeholder.svg?height=80&width=120" },
    { name: "Georgia Institute of Technology", logo: "/placeholder.svg?height=80&width=120" },
    { name: "University of Toronto", logo: "/placeholder.svg?height=80&width=120" },
    { name: "ETH Zurich", logo: "/placeholder.svg?height=80&width=120" },
    { name: "National University of Singapore", logo: "/placeholder.svg?height=80&width=120" },
    { name: "University of Melbourne", logo: "/placeholder.svg?height=80&width=120" },
  ]

  const services = [
    {
      icon: Code,
      title: "Web Development",
      description: "Custom web applications built with modern frameworks and technologies",
      features: ["React & Next.js", "Full-Stack Solutions", "API Development", "Database Design"],
      color: "from-blue-600 to-blue-700",
    },
    {
      icon: Smartphone,
      title: "Mobile Development",
      description: "Native and cross-platform mobile applications for iOS and Android",
      features: ["React Native", "Flutter", "Native iOS/Android", "App Store Deployment"],
      color: "from-purple-600 to-purple-700",
    },
    {
      icon: Cloud,
      title: "Cloud Solutions",
      description: "Scalable cloud infrastructure and deployment solutions",
      features: ["AWS & Azure", "DevOps", "Microservices", "Auto-scaling"],
      color: "from-green-600 to-green-700",
    },
    {
      icon: Database,
      title: "Data Analytics",
      description: "Advanced data processing and analytics solutions",
      features: ["Big Data", "Machine Learning", "Data Visualization", "Predictive Analytics"],
      color: "from-orange-600 to-orange-700",
    },
    {
      icon: Shield,
      title: "Cybersecurity",
      description: "Comprehensive security solutions and vulnerability assessments",
      features: ["Security Audits", "Penetration Testing", "Compliance", "Risk Assessment"],
      color: "from-red-600 to-red-700",
    },
    {
      icon: Zap,
      title: "AI & Automation",
      description: "Artificial intelligence and process automation solutions",
      features: ["ChatBots", "Process Automation", "AI Integration", "Workflow Optimization"],
      color: "from-indigo-600 to-indigo-700",
    },
  ]

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Computer Science Student",
      university: "Stanford University",
      image: "/placeholder.svg?height=80&width=80",
      quote:
        "MITS helped me build my first startup's MVP. Their expertise and student-friendly approach made all the difference.",
      rating: 5,
    },
    {
      name: "Marcus Johnson",
      role: "PhD Candidate",
      university: "MIT",
      image: "/placeholder.svg?height=80&width=80",
      quote:
        "The cloud infrastructure they set up for our research project scaled perfectly. Exceptional technical knowledge.",
      rating: 5,
    },
    {
      name: "Dr. Emily Rodriguez",
      role: "Professor of Engineering",
      university: "UC Berkeley",
      image: "/placeholder.svg?height=80&width=80",
      quote: "MITS has been instrumental in digitizing our curriculum. Their solutions are innovative and reliable.",
      rating: 5,
    },
    {
      name: "Alex Kim",
      role: "Graduate Student",
      university: "Harvard University",
      image: "/placeholder.svg?height=80&width=80",
      quote: "From concept to deployment, MITS guided us through every step. Our app now has over 10k downloads!",
      rating: 5,
    },
  ]

  const teamMembers = [
    {
      name: "David Chen",
      role: "Founder & CEO",
      image: "/placeholder.svg?height=120&width=120",
      bio: "Former Google engineer with 10+ years in tech leadership",
    },
    {
      name: "Maria Santos",
      role: "CTO",
      image: "/placeholder.svg?height=120&width=120",
      bio: "MIT graduate specializing in distributed systems and AI",
    },
    {
      name: "James Wilson",
      role: "Head of Development",
      image: "/placeholder.svg?height=120&width=120",
      bio: "Full-stack expert with experience at top Silicon Valley startups",
    },
    {
      name: "Lisa Zhang",
      role: "Head of Design",
      image: "/placeholder.svg?height=120&width=120",
      bio: "Award-winning UX designer focused on accessibility and user experience",
    },
  ]

  const blogPosts = [
    {
      title: "The Future of Student Technology",
      excerpt: "Exploring how emerging technologies are reshaping education and student experiences.",
      date: "Dec 15, 2024",
      image: "/placeholder.svg?height=200&width=300",
      category: "Technology",
    },
    {
      title: "Building Your First Startup as a Student",
      excerpt: "A comprehensive guide to launching a tech startup while managing academic responsibilities.",
      date: "Dec 10, 2024",
      image: "/placeholder.svg?height=200&width=300",
      category: "Entrepreneurship",
    },
    {
      title: "Cloud Computing for Academic Research",
      excerpt: "How cloud technologies are accelerating research and collaboration in universities.",
      date: "Dec 5, 2024",
      image: "/placeholder.svg?height=200&width=300",
      category: "Research",
    },
  ]

  const socialStats = [
    { platform: "Active Students", count: "50K+", icon: Users, color: "text-white", bg: "from-blue-600 to-blue-700" },
    { platform: "Countries", count: "25+", icon: Globe, color: "text-white", bg: "from-green-600 to-green-700" },
    { platform: "Success Rate", count: "98%", icon: Award, color: "text-white", bg: "from-purple-600 to-purple-700" },
    {
      platform: "Growth Rate",
      count: "150%",
      suffix: "YoY",
      icon: TrendingUp,
      color: "text-white",
      bg: "from-orange-600 to-orange-700",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b-2 border-gray-200 bg-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-20 items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 shadow-lg"></div>
              <span className="text-2xl font-bold text-gray-900">MITS</span>
            </div>
            <nav className="hidden lg:flex items-center space-x-8">
              <Link href="#about" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                About
              </Link>
              <Link href="#services" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Services
              </Link>
              <Link href="#universities" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Partners
              </Link>
              <Link href="#testimonials" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Testimonials
              </Link>
              <Link href="#team" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Team
              </Link>
              <Link href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Contact
              </Link>
            </nav>
            <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all font-semibold shadow-lg">
              Get Started
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32 relative">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8 text-white">
              <div className="space-y-6">
                <div className="inline-flex items-center px-4 py-2 bg-white/10 rounded-full text-sm font-medium backdrop-blur-sm">
                  <Zap className="w-4 h-4 mr-2" />
                  Trusted by 50K+ Students Worldwide
                </div>
                <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight">
                  Empowering Students Through
                  <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                    {" "}
                    Technology
                  </span>
                </h1>
                <p className="text-xl text-gray-200 leading-relaxed max-w-2xl">
                  Micro Information Technology Services (MITS) bridges the gap between academic excellence and industry
                  innovation, providing cutting-edge tech solutions for students and universities worldwide.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-6">
                <button className="bg-gradient-to-r from-yellow-500 to-orange-600 text-black px-10 py-4 rounded-xl hover:from-yellow-400 hover:to-orange-500 transition-all font-bold text-lg shadow-xl">
                  Start Your Project
                  <ArrowRight className="w-5 h-5 ml-2 inline" />
                </button>
                <button className="border-2 border-white text-white px-10 py-4 rounded-xl hover:bg-white hover:text-gray-900 transition-all font-semibold text-lg flex items-center justify-center">
                  <Play className="w-5 h-5 mr-2" />
                  Watch Demo
                </button>
              </div>
              <div className="grid grid-cols-3 gap-8 pt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-400">50K+</div>
                  <div className="text-gray-300">Students Served</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-400">500+</div>
                  <div className="text-gray-300">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-400">98%</div>
                  <div className="text-gray-300">Success Rate</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-8 backdrop-blur-sm border border-white/10">
                <Image
                  src="/placeholder.svg?height=500&width=500"
                  alt="Students collaborating with advanced technology and AI"
                  width={500}
                  height={500}
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-80 animate-pulse"></div>
              <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-gradient-to-br from-green-400 to-blue-500 rounded-full opacity-80 animate-pulse"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive technology solutions designed specifically for students, researchers, and academic
              institutions.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-2 border-transparent hover:border-blue-200"
              >
                <div
                  className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
                >
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <ul className="space-y-3">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-700">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="mt-8 w-full bg-gray-900 text-white py-3 rounded-xl hover:bg-gray-800 transition-colors font-semibold">
                  Learn More
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section id="about" className="py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center space-y-6 mb-20">
              <h2 className="text-4xl sm:text-5xl font-bold text-gray-900">Our Mission</h2>
              <p className="text-2xl text-gray-600 leading-relaxed max-w-4xl mx-auto">
                To democratize access to advanced technology solutions and empower the next generation of innovators
                through comprehensive digital services, mentorship, and industry connections.
              </p>
            </div>
            <div className="grid lg:grid-cols-3 gap-12">
              <div className="text-center space-y-6 p-8 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Student-Centric Approach</h3>
                <p className="text-gray-700 leading-relaxed">
                  Every solution is tailored specifically for student needs, academic requirements, and budget
                  constraints. We understand the unique challenges students face and design our services accordingly.
                </p>
              </div>
              <div className="text-center space-y-6 p-8 bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                  <Globe className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Global Network</h3>
                <p className="text-gray-700 leading-relaxed">
                  Our extensive partnership network spans 25+ countries, connecting students worldwide and fostering
                  international collaboration on technology projects and research initiatives.
                </p>
              </div>
              <div className="text-center space-y-6 p-8 bg-gradient-to-br from-green-50 to-green-100 rounded-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-green-600 to-green-700 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                  <Award className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Excellence & Innovation</h3>
                <p className="text-gray-700 leading-relaxed">
                  We maintain the highest standards of quality while staying at the forefront of technological
                  innovation. Our 98% success rate speaks to our commitment to excellence.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* University Affiliations */}
      <section id="universities" className="py-24 bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-4xl sm:text-5xl font-bold text-white">Trusted by Leading Universities</h2>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto">
              We're proud to partner with prestigious institutions worldwide, supporting their students and faculty in
              achieving technological excellence and driving innovation in education.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-6">
            {universities.map((university, index) => (
              <div key={index} className="group">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300 h-24 flex items-center justify-center border border-white/10">
                  <Image
                    src={university.logo || "/placeholder.svg"}
                    alt={`${university.name} logo`}
                    width={120}
                    height={80}
                    className="max-w-full max-h-full object-contain opacity-70 group-hover:opacity-100 transition-opacity duration-300 filter brightness-0 invert"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Media Statistics */}
      <section className="py-24 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-4xl sm:text-5xl font-bold text-white">Our Impact in Numbers</h2>
            <p className="text-xl text-blue-100 max-w-4xl mx-auto">
              Join thousands of students and institutions who trust MITS for their technology needs and digital
              transformation.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {socialStats.map((stat, index) => (
              <div
                key={index}
                className="text-center space-y-6 p-8 rounded-2xl bg-white/10 backdrop-blur-sm hover:bg-white/20 transition-all border border-white/20"
              >
                <div
                  className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${stat.bg} shadow-xl flex items-center justify-center mx-auto`}
                >
                  <stat.icon className="w-10 h-10 text-white" />
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-white">{stat.count}</div>
                  <div className="text-blue-100 text-lg">
                    {stat.platform}
                    {stat.suffix && <span className="block text-sm opacity-80">{stat.suffix}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900">What Students Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hear from students and faculty who have transformed their ideas into reality with MITS.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <blockquote className="text-gray-700 mb-6 leading-relaxed">"{testimonial.quote}"</blockquote>
                <div className="flex items-center">
                  <Image
                    src={testimonial.image || "/placeholder.svg"}
                    alt={`${testimonial.name} profile picture`}
                    width={60}
                    height={60}
                    className="rounded-full mr-4"
                  />
                  <div>
                    <div className="font-bold text-gray-900">{testimonial.name}</div>
                    <div className="text-gray-600 text-sm">{testimonial.role}</div>
                    <div className="text-blue-600 text-sm font-medium">{testimonial.university}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="py-24 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900">Meet Our Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our diverse team of experts brings together decades of experience from top tech companies and
              universities.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow text-center"
              >
                <Image
                  src={member.image || "/placeholder.svg"}
                  alt={`${member.name} profile picture`}
                  width={120}
                  height={120}
                  className="rounded-full mx-auto mb-6"
                />
                <h3 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h3>
                <div className="text-blue-600 font-semibold mb-4">{member.role}</div>
                <p className="text-gray-600 leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog/News Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900">Latest Insights</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Stay updated with the latest trends in technology, education, and student innovation.
            </p>
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <article
                key={index}
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden border-2 border-gray-100"
              >
                <Image
                  src={post.image || "/placeholder.svg"}
                  alt={post.title}
                  width={400}
                  height={250}
                  className="w-full h-48 object-cover"
                />
                <div className="p-8">
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                      {post.category}
                    </span>
                    <div className="flex items-center text-gray-500 text-sm">
                      <Calendar className="w-4 h-4 mr-1" />
                      {post.date}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{post.title}</h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">{post.excerpt}</p>
                  <Link href="#" className="text-blue-600 font-semibold hover:text-blue-700 flex items-center">
                    Read More
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center space-y-6 mb-20">
              <h2 className="text-4xl sm:text-5xl font-bold text-white">Get In Touch</h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Ready to start your next project? Let's discuss how we can help bring your ideas to life.
              </p>
            </div>
            <div className="grid lg:grid-cols-2 gap-12">
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Email Us</h3>
                    <p className="text-gray-300">hello@mits.tech</p>
                    <p className="text-gray-300">support@mits.tech</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Call Us</h3>
                    <p className="text-gray-300">+1 (555) 123-4567</p>
                    <p className="text-gray-300">+1 (555) 987-6543</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Visit Us</h3>
                    <p className="text-gray-300">123 Innovation Drive</p>
                    <p className="text-gray-300">Tech Valley, CA 94000</p>
                  </div>
                </div>
              </div>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <input
                    type="text"
                    placeholder="First Name"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <input
                  type="email"
                  placeholder="Email Address"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                />
                <input
                  type="text"
                  placeholder="University/Organization"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                />
                <textarea
                  rows={6}
                  placeholder="Tell us about your project..."
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 resize-none"
                ></textarea>
                <button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all font-semibold text-lg">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Social Media Links */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold text-white">Stay Connected</h2>
              <p className="text-xl text-blue-100 max-w-2xl mx-auto">
                Follow us on social media for the latest updates, tech insights, and student success stories.
              </p>
            </div>
            <div className="flex justify-center space-x-6">
              <Link
                href="#"
                className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center hover:bg-white/30 transition-colors backdrop-blur-sm"
              >
                <Facebook className="w-8 h-8 text-white" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link
                href="#"
                className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center hover:bg-white/30 transition-colors backdrop-blur-sm"
              >
                <Twitter className="w-8 h-8 text-white" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link
                href="#"
                className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center hover:bg-white/30 transition-colors backdrop-blur-sm"
              >
                <Instagram className="w-8 h-8 text-white" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link
                href="#"
                className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center hover:bg-white/30 transition-colors backdrop-blur-sm"
              >
                <Linkedin className="w-8 h-8 text-white" />
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 shadow-lg"></div>
                <span className="text-2xl font-bold">MITS</span>
              </div>
              <p className="text-gray-400 leading-relaxed max-w-md">
                Empowering students through innovative technology solutions and global partnerships. Building the future
                of education, one project at a time.
              </p>
              <div className="flex space-x-4">
                <Link
                  href="#"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
                >
                  <Facebook className="w-5 h-5" />
                </Link>
                <Link
                  href="#"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
                >
                  <Twitter className="w-5 h-5" />
                </Link>
                <Link
                  href="#"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                </Link>
                <Link
                  href="#"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
                >
                  <Linkedin className="w-5 h-5" />
                </Link>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-bold">Services</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Web Development
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Mobile Apps
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Cloud Solutions
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Data Analytics
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    AI & Automation
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-bold">Company</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Our Team
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-bold">Support</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Documentation
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Micro Information Technology Services (MITS). All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
