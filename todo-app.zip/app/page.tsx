import Component from "../todo-app"

export default function Page() {
  return <Component />
}
